﻿using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.Networking.Match;
using System.Collections;

public class NetWorkMan : NetworkManager {

	private NetworkMatch networkMatch;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		var nm = GetComponent<NetworkMatch> ();
		if (nm != null) {
			networkMatch = nm as NetworkMatch;
			UnityEngine.Networking.Types.AppID appid = (UnityEngine.Networking.Types.AppID)94451;
			networkMatch.SetProgramAppID (appid);
		}
	}
}
